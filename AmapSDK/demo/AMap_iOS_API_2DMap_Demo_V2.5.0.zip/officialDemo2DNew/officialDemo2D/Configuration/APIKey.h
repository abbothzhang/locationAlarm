//
//  APIKey.h
//  SearchV3Demo
//
//  Created by songjian on 13-8-14.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#ifndef SearchV3Demo_APIKey_h
#define SearchV3Demo_APIKey_h

/* 使用高德地图API，请注册Key，注册地址：http://lbs.amap.com/console/key */

const static NSString *APIKey = @"";

#endif
