//
//  main.m
//  officialDemo2D
//
//  Created by 刘博 on 13-9-6.
//  Copyright (c) 2013年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MAAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MAAppDelegate class]));
    }
}
