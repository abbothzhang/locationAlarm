//
//  ScreenshotDetailViewController.h
//  Category_demo
//
//  Created by songjian on 13-5-15.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScreenshotDetailViewController : UIViewController

@property (nonatomic, strong) UIImage *screenshotImage;

@end
