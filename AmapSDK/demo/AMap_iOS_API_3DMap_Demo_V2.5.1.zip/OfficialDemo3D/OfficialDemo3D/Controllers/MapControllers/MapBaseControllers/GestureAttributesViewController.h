//
//  GestureAttributesViewController.h
//  Category_demo
//
//  Created by songjian on 13-3-21.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "BaseMapViewController.h"

@interface GestureAttributesViewController : BaseMapViewController

@end
