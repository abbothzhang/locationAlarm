//
//  RoadDetailViewController.h
//  SearchV3Demo
//
//  Created by songjian on 13-8-26.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface RoadDetailViewController : UIViewController

@property (nonatomic, strong) AMapRoad *road;

@end
