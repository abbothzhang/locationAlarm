var interface_a_map_app_url =
[
    [ "android", "interface_a_map_app_url.html#afbbf2da8032166c3eade192430d4ea13", null ],
    [ "ios", "interface_a_map_app_url.html#a09a4dbc674244eaf934f7728e3b6f253", null ],
    [ "wp", "interface_a_map_app_url.html#a9e3cbd0e4db47b3079703cfaea4a9884", null ]
];