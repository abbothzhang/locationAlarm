var interface_m_a_overlay_renderer =
[
    [ "canDrawMapRect:zoomScale:", "interface_m_a_overlay_renderer.html#aa24c585df138cf2e001199210ef9eaac", null ],
    [ "drawMapRect:zoomScale:inContext:", "interface_m_a_overlay_renderer.html#aebb951457efc4bdbee62dbd6d1e1e07e", null ],
    [ "initWithOverlay:", "interface_m_a_overlay_renderer.html#a86e462159e103c9df868be1e997d9aa6", null ],
    [ "mapPointForPoint:", "interface_m_a_overlay_renderer.html#ad68729a4a56c780a0254f43abb8c577b", null ],
    [ "mapRectForRect:", "interface_m_a_overlay_renderer.html#a4f591cb073ef5e066a721346c3c40246", null ],
    [ "pointForMapPoint:", "interface_m_a_overlay_renderer.html#a22d5bc343dca1ba32c7a9d4079030cdd", null ],
    [ "rectForMapRect:", "interface_m_a_overlay_renderer.html#a1611f4df96ca1e39bdb8ed0c75bc9bd2", null ],
    [ "setNeedsDisplay", "interface_m_a_overlay_renderer.html#a1ad7bbcd2202f89e0480d3e30ff18f6a", null ],
    [ "setNeedsDisplayInMapRect:", "interface_m_a_overlay_renderer.html#aadcd3f2132a535d2c70d37e628da3aef", null ],
    [ "setNeedsDisplayInMapRect:zoomScale:", "interface_m_a_overlay_renderer.html#a6903192bbc92746656e35109e580bfa5", null ],
    [ "alpha", "interface_m_a_overlay_renderer.html#a6b04f47e8e136a0c6037d44a6a6ab1c3", null ],
    [ "contentScaleFactor", "interface_m_a_overlay_renderer.html#a6c60636a833a63531a2194c6795413c3", null ],
    [ "overlay", "interface_m_a_overlay_renderer.html#a0ca43223d15e2228c6006214e93bfe18", null ]
];