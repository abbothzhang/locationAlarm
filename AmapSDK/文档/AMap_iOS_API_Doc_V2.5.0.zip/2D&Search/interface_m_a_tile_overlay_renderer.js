var interface_m_a_tile_overlay_renderer =
[
    [ "initWithTileOverlay:", "interface_m_a_tile_overlay_renderer.html#a651f27d321bc209ce8c2574148f0784a", null ],
    [ "reloadData", "interface_m_a_tile_overlay_renderer.html#aa7e8ceb17e2af2777441fe7fd3ee0c22", null ],
    [ "tileOverlay", "interface_m_a_tile_overlay_renderer.html#a5fcdcbd7f0a6bb14dcb27249ba6f0edb", null ]
];