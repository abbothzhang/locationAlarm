var interface_a_map_cinema_deep_content =
[
    [ "is3D", "interface_a_map_cinema_deep_content.html#a18f1602427cc1b454f965768dbd92669", null ],
    [ "movies", "interface_a_map_cinema_deep_content.html#ab400e878f40177005b4598e70555b050", null ],
    [ "opentime", "interface_a_map_cinema_deep_content.html#a7934099a026f9fe681b695ce95324b1d", null ],
    [ "opentimeGDF", "interface_a_map_cinema_deep_content.html#af17c8eaa8b67dcc729c4d0c17791821d", null ],
    [ "parking", "interface_a_map_cinema_deep_content.html#a4139fb55909eb20d5412b4270055ebbe", null ]
];