var interface_a_map_navigation_search_response =
[
    [ "count", "interface_a_map_navigation_search_response.html#ab21c4dcf46d2e9f2e508231faa6acd4a", null ],
    [ "route", "interface_a_map_navigation_search_response.html#ab73e273024e7d6b26169f0dc705f8d16", null ]
];