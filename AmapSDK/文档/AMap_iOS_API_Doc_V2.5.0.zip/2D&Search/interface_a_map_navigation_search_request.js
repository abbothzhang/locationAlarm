var interface_a_map_navigation_search_request =
[
    [ "avoidpolygons", "interface_a_map_navigation_search_request.html#ad8823c6271c035e3616593a5e68ee974", null ],
    [ "avoidroad", "interface_a_map_navigation_search_request.html#acf465785e010b14d3ee9cc90eafd6a9a", null ],
    [ "city", "interface_a_map_navigation_search_request.html#a722146dcdbd87db1b7ee520f33ae37eb", null ],
    [ "destination", "interface_a_map_navigation_search_request.html#acc3d179d85758b8b26c6f3530ea53bf0", null ],
    [ "destinationId", "interface_a_map_navigation_search_request.html#aa4e8c325aa219d0c1c50910448d212bb", null ],
    [ "multipath", "interface_a_map_navigation_search_request.html#a1a24ddbdc58f0a9e0696a1829f423d54", null ],
    [ "nightflag", "interface_a_map_navigation_search_request.html#a3ecd86b7864a30e2428b1c1da45b2d04", null ],
    [ "origin", "interface_a_map_navigation_search_request.html#a4499f2f00b0610caf29113d3911985a6", null ],
    [ "originId", "interface_a_map_navigation_search_request.html#a7a7203858c872f270d513439afb5d75d", null ],
    [ "requireExtension", "interface_a_map_navigation_search_request.html#a56c9fadfc1cd1b861ed7cb14121d1e58", null ],
    [ "searchType", "interface_a_map_navigation_search_request.html#a63b70ebdec4e1311e79141d6aeadd4e5", null ],
    [ "strategy", "interface_a_map_navigation_search_request.html#a73338f16c9b236a64b927aab8dbcc2f0", null ],
    [ "waypoints", "interface_a_map_navigation_search_request.html#ac70f40c736d2fb370f2f2fb143140c31", null ]
];