var interface_a_map_re_geocode_search_request =
[
    [ "location", "interface_a_map_re_geocode_search_request.html#a874c1c507c0b27f85285acb0adabc20c", null ],
    [ "poiIdFilter", "interface_a_map_re_geocode_search_request.html#a5f2e23672094c05c532734fdba522666", null ],
    [ "radius", "interface_a_map_re_geocode_search_request.html#a74efc907f4057d8e7a148335289548d9", null ],
    [ "requireExtension", "interface_a_map_re_geocode_search_request.html#a7853296f29607051a4f41f520206ea79", null ],
    [ "searchType", "interface_a_map_re_geocode_search_request.html#a1213328fff3dc649efe87ee5e4b1533f", null ]
];