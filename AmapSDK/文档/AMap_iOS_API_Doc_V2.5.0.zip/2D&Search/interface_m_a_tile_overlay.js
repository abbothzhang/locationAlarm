var interface_m_a_tile_overlay =
[
    [ "initWithURLTemplate:", "interface_m_a_tile_overlay.html#a2d1b7cd463837ceb3325833a793cad64", null ],
    [ "loadTileAtPath:result:", "interface_m_a_tile_overlay.html#ae962acaaa00b13f494e261d61492a599", null ],
    [ "URLForTilePath:", "interface_m_a_tile_overlay.html#aacc5d904fedafb39cc635c042fa56599", null ],
    [ "boundingMapRect", "interface_m_a_tile_overlay.html#a769d8fc99b4862bc8c1a0991d096f914", null ],
    [ "maximumZ", "interface_m_a_tile_overlay.html#a221f94bc4da2947ac558e9f21b4f9ed2", null ],
    [ "minimumZ", "interface_m_a_tile_overlay.html#a1248b62b980f16dcb24f28de6afdf8b7", null ],
    [ "tileSize", "interface_m_a_tile_overlay.html#aaa7c80906a1529680b45d5c306f74fcf", null ],
    [ "URLTemplate", "interface_m_a_tile_overlay.html#aaff14d9c454fae49ccf6b5d6160e9831", null ]
];