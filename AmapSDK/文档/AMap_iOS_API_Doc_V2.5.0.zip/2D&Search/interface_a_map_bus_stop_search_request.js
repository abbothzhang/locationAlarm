var interface_a_map_bus_stop_search_request =
[
    [ "city", "interface_a_map_bus_stop_search_request.html#a182e64bd89327ecb5beab8c23d87f67b", null ],
    [ "keywords", "interface_a_map_bus_stop_search_request.html#affd78983bfd59e77e935c572b89987e8", null ],
    [ "offset", "interface_a_map_bus_stop_search_request.html#aac7a1fe94e1f5b22d3782b9fd548e71c", null ],
    [ "page", "interface_a_map_bus_stop_search_request.html#afaea21dc9e10bfc297c6158ba24a8004", null ],
    [ "searchType", "interface_a_map_bus_stop_search_request.html#a16ed8c38a7ae2c37116c335ef739e275", null ]
];