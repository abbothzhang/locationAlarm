var interface_a_map_t_m_c =
[
    [ "distance", "interface_a_map_t_m_c.html#ad07429a2b88d69b12aca30db58a6ccc0", null ],
    [ "lcode", "interface_a_map_t_m_c.html#a97823d6ad119061fb630872781fca040", null ],
    [ "status", "interface_a_map_t_m_c.html#a68d2f10fe58bdb160d99d55dac69d76d", null ]
];