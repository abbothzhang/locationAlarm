var interface_m_a_map_services =
[
    [ "apiKey", "interface_m_a_map_services.html#a8c074369810d7f3f5933180c0f8ae92d", null ],
    [ "SDKVersion", "interface_m_a_map_services.html#a751d37e45c17b7c3236bb3c4e02bb25d", null ]
];