var interface_a_map_transit =
[
    [ "cost", "interface_a_map_transit.html#abdd81c5a0ffa247c6811a6f7678b2695", null ],
    [ "duration", "interface_a_map_transit.html#a8e2d479e47efae35b86bdcaaf540ddc5", null ],
    [ "nightflag", "interface_a_map_transit.html#a361fe39c29dd2d1c01a2dc6c1cd45631", null ],
    [ "segments", "interface_a_map_transit.html#a327ba2a7bfc751f151c9340cef6f25ae", null ],
    [ "walkingDistance", "interface_a_map_transit.html#af5cf9770ff2231dfa3ded8430db52874", null ]
];