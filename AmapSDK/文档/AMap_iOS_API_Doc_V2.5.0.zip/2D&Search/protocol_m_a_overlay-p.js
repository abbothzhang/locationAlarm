var protocol_m_a_overlay_p =
[
    [ "intersectsMapRect:", "protocol_m_a_overlay-p.html#a9da6459282d9282a133ed6442abb7af2", null ],
    [ "boundingMapRect", "protocol_m_a_overlay-p.html#a27a84e2a81f014153eb3f50279f36e5a", null ],
    [ "coordinate", "protocol_m_a_overlay-p.html#a256b0178b2cfa65ff841495a9d792400", null ]
];