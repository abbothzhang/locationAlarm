var protocol_a_map_search_delegate_p =
[
    [ "onBusLineSearchDone:response:", "protocol_a_map_search_delegate-p.html#ad037cfbe8f7d5f3b7ba69baef0befef5", null ],
    [ "onBusStopSearchDone:response:", "protocol_a_map_search_delegate-p.html#af90a721d370e4de4df57b46890011d3b", null ],
    [ "onDistrictSearchDone:response:", "protocol_a_map_search_delegate-p.html#aa8574062481da5b94ae3b77fec276085", null ],
    [ "onGeocodeSearchDone:response:", "protocol_a_map_search_delegate-p.html#a5d30cc6b574e50d0797b98b058d0b764", null ],
    [ "onInputTipsSearchDone:response:", "protocol_a_map_search_delegate-p.html#a72a41043ca8ae09caa63289ea5237012", null ],
    [ "onNavigationSearchDone:response:", "protocol_a_map_search_delegate-p.html#a72929231b02fc3ab8d67f4bbd8a2b5a0", null ],
    [ "onPlaceSearchDone:response:", "protocol_a_map_search_delegate-p.html#a6acfd8d3680b726258a82e811e1009ee", null ],
    [ "onReGeocodeSearchDone:response:", "protocol_a_map_search_delegate-p.html#a9985fe475c78fcb235777acf3188cb2f", null ],
    [ "search:error:", "protocol_a_map_search_delegate-p.html#aa6baff8cc5376541a909990fd118c8c2", null ],
    [ "searchRequest:didFailWithError:", "protocol_a_map_search_delegate-p.html#afa4f1addb21ccc2be3c7de457b4fd8c4", null ]
];