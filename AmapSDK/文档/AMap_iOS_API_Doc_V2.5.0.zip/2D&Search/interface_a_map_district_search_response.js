var interface_a_map_district_search_response =
[
    [ "count", "interface_a_map_district_search_response.html#a9a4c3d11af10a7ee8841af2b7ab46b52", null ],
    [ "districts", "interface_a_map_district_search_response.html#a8b2ef278d912d749d27ecaff15d82730", null ]
];