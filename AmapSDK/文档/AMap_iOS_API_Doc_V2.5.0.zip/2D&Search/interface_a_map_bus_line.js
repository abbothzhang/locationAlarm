var interface_a_map_bus_line =
[
    [ "arrivalStop", "interface_a_map_bus_line.html#aaab507fc57b0d06c398085425c691404", null ],
    [ "basicPrice", "interface_a_map_bus_line.html#ae7fc635e7e90fe3bba997883c6e3996f", null ],
    [ "bounds", "interface_a_map_bus_line.html#a5cba3f9fcc85637ad9f1b2404b3ddaf9", null ],
    [ "busStops", "interface_a_map_bus_line.html#ada9a0cb5dc921e26cdc14f2c029be9ea", null ],
    [ "busStopsNum", "interface_a_map_bus_line.html#abc66ebc9444cd49d093c8d68fbad5edd", null ],
    [ "citycode", "interface_a_map_bus_line.html#ab8c0cfa47778f2930ab16eb1039a1e93", null ],
    [ "company", "interface_a_map_bus_line.html#a4aa2168724231b743769f6b3f8e45760", null ],
    [ "departureStop", "interface_a_map_bus_line.html#a832213d6622f606e78d6970d1ba7d3dd", null ],
    [ "distance", "interface_a_map_bus_line.html#a35beddd7e64891e02b78444c80989043", null ],
    [ "duration", "interface_a_map_bus_line.html#aef9fd26fcaad07467799cdab0ead7509", null ],
    [ "endStop", "interface_a_map_bus_line.html#af999c9c91e0a2c68ca3f1a1fa616856e", null ],
    [ "endTime", "interface_a_map_bus_line.html#afc10a86f73b54ce5ab9fded25ea90ba5", null ],
    [ "gridcode", "interface_a_map_bus_line.html#af6bad7c0524b08817c1acbba337e0289", null ],
    [ "name", "interface_a_map_bus_line.html#a87e73e61ec5ff0b11bfd100774c61550", null ],
    [ "polyline", "interface_a_map_bus_line.html#a1f968c896c8249da93062fe684187e2c", null ],
    [ "startStop", "interface_a_map_bus_line.html#a90072c3f91a511ce82fbbee9b673c4a6", null ],
    [ "startTime", "interface_a_map_bus_line.html#a438ddb2f8e8364cfa262d977ac79ec3a", null ],
    [ "totalPrice", "interface_a_map_bus_line.html#a95aa06c3e3f323d75b4851146fddaf04", null ],
    [ "type", "interface_a_map_bus_line.html#acc74d906de687d8e96c51a6189a7949c", null ],
    [ "uid", "interface_a_map_bus_line.html#aac351ce7c292ac9df46f9676b428ea3d", null ]
];