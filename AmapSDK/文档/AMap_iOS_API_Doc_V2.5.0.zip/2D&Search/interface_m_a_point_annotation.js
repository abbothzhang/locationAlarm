var interface_m_a_point_annotation =
[
    [ "coordinate", "interface_m_a_point_annotation.html#a537233dd9af6c38478bf748e4abf3a6e", null ]
];