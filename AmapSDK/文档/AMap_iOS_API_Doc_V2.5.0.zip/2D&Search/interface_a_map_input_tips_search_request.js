var interface_a_map_input_tips_search_request =
[
    [ "city", "interface_a_map_input_tips_search_request.html#a32c65814cf8b8355d2d6305077f0d104", null ],
    [ "keywords", "interface_a_map_input_tips_search_request.html#a34eeecd5938946579b7d8841d3249529", null ],
    [ "searchType", "interface_a_map_input_tips_search_request.html#aa76b59292918d5550ff84332fc9f0e09", null ],
    [ "types", "interface_a_map_input_tips_search_request.html#aee40ca26d0f1c160f77f66fb8925db39", null ]
];