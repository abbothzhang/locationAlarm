var searchData=
[
  ['rectformaprect_3a',['rectForMapRect:',['../interface_m_a_overlay_renderer.html#a1611f4df96ca1e39bdb8ed0c75bc9bd2',1,'MAOverlayRenderer::rectForMapRect:()'],['../interface_m_a_overlay_view.html#af30d3dc8093c7910daad0a24d865fdc8',1,'MAOverlayView::rectForMapRect:()']]],
  ['regionthatfits_3a',['regionThatFits:',['../interface_m_a_map_view.html#ad341e45f0a9f22982aea40d7b3380584',1,'MAMapView']]],
  ['reloaddata',['reloadData',['../interface_m_a_tile_overlay_renderer.html#aa7e8ceb17e2af2777441fe7fd3ee0c22',1,'MATileOverlayRenderer::reloadData()'],['../interface_m_a_tile_overlay_view.html#a7ce8eb02e78fd71af604fa4a11bceb40',1,'MATileOverlayView::reloadData()']]],
  ['removeannotation_3a',['removeAnnotation:',['../interface_m_a_map_view.html#a5256e2a0404a95d7e623b166f5c50bfa',1,'MAMapView']]],
  ['removeannotations_3a',['removeAnnotations:',['../interface_m_a_map_view.html#a4848573321201d75f277c14a94285620',1,'MAMapView']]],
  ['removeoverlay_3a',['removeOverlay:',['../interface_m_a_map_view.html#a702100d6e068b63c831ec5c292446ec8',1,'MAMapView']]],
  ['removeoverlays_3a',['removeOverlays:',['../interface_m_a_map_view.html#ade964fb9586705638125b8188ef58e4c',1,'MAMapView']]],
  ['rendererforoverlay_3a',['rendererForOverlay:',['../interface_m_a_map_view.html#a36dffd1967c8c4dd1f8841c64dacb136',1,'MAMapView']]]
];
