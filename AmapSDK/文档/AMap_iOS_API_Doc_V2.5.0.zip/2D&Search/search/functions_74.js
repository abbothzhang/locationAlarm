var searchData=
[
  ['takesnapshotinrect_3a',['takeSnapshotInRect:',['../category_m_a_map_view_07_snapshot_08.html#a184e6408f2eff4a2f58ea779c63845a2',1,'MAMapView(Snapshot)::takeSnapshotInRect:()'],['../interface_m_a_map_view.html#a184e6408f2eff4a2f58ea779c63845a2',1,'MAMapView::takeSnapshotInRect:()']]],
  ['takesnapshotinrect_3awithcompletionblock_3a',['takeSnapshotInRect:withCompletionBlock:',['../category_m_a_map_view_07_snapshot_08.html#afb80dedda65c4789f776cea9e16174f8',1,'MAMapView(Snapshot)::takeSnapshotInRect:withCompletionBlock:()'],['../interface_m_a_map_view.html#afb80dedda65c4789f776cea9e16174f8',1,'MAMapView::takeSnapshotInRect:withCompletionBlock:()']]],
  ['tipwithname_3aadcode_3adistrict_3a',['tipWithName:adcode:district:',['../interface_a_map_tip.html#a0e7e159b80a6862527a82d4fdee1229c',1,'AMapTip']]],
  ['tmcwithlcode_3adistance_3astatus_3a',['TMCWithLCode:distance:status:',['../interface_a_map_t_m_c.html#a2e4e3e2ce6718d176502737ed11f75cf',1,'AMapTMC']]]
];
