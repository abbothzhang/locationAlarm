var interface_a_map_geo_point =
[
    [ "latitude", "interface_a_map_geo_point.html#acf46a26364949fef95c27ce703afd9a1", null ],
    [ "longitude", "interface_a_map_geo_point.html#a7f103f49d5473751f205f95d2ab6d766", null ]
];