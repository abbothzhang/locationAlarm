var interface_m_a_navi_config =
[
    [ "appName", "interface_m_a_navi_config.html#aa953550ce7547a322f66b7b98f4d9ad9", null ],
    [ "appScheme", "interface_m_a_navi_config.html#a6e81b12fe958539a2a32f6144c1981d3", null ],
    [ "destination", "interface_m_a_navi_config.html#ad01878faa15ccba4b988513e25a62595", null ],
    [ "style", "interface_m_a_navi_config.html#acefe13df36f09e81f2806d019ed72d50", null ]
];