var interface_a_map_biz_extention =
[
    [ "cost", "interface_a_map_biz_extention.html#aa10141a1fc02af14579a4c3250dcd0aa", null ],
    [ "hasDiscount", "interface_a_map_biz_extention.html#aa51f630331766236eafee5991fd23ae2", null ],
    [ "hasGroupbuy", "interface_a_map_biz_extention.html#a265993ea4a91adfe137bf758c4e5590e", null ],
    [ "lowestPriceForHotel", "interface_a_map_biz_extention.html#a3f41dff99609616131546b4c527bdcfd", null ],
    [ "mealOrderingForDining", "interface_a_map_biz_extention.html#ade8f49f29b9785d541cee73b31729fee", null ],
    [ "rating", "interface_a_map_biz_extention.html#a4f65f88961e4abf438a38ca906516967", null ],
    [ "seatOrderingForCinema", "interface_a_map_biz_extention.html#a156e5bbacf9a7f10081601b0087624a4", null ],
    [ "starForHotel", "interface_a_map_biz_extention.html#aa828d8c2e32ac2c7833aa594380344b4", null ],
    [ "ticketOrderingForScenic", "interface_a_map_biz_extention.html#ab275f4a8ce0f8ab8bf77bc7d7ada6db0", null ]
];