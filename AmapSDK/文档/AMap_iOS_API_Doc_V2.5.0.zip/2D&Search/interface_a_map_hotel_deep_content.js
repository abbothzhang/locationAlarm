var interface_a_map_hotel_deep_content =
[
    [ "addition", "interface_a_map_hotel_deep_content.html#af553a05a91651fa1a65562fe7777deac", null ],
    [ "environmentRating", "interface_a_map_hotel_deep_content.html#af0e96db6193f5833719be5eb8012d3a7", null ],
    [ "faciRating", "interface_a_map_hotel_deep_content.html#a94e6403341c0e0e9c9f506cd4e8f6f0f", null ],
    [ "healthRating", "interface_a_map_hotel_deep_content.html#acd4a77440bd66b1b29df49eb86950c5a", null ],
    [ "lowestPrice", "interface_a_map_hotel_deep_content.html#ab0b13fd28bb29608db8057e0a96c6441", null ],
    [ "rooms", "interface_a_map_hotel_deep_content.html#aab9718aafd62c4abfb3fd3320591ef8b", null ],
    [ "serviceRating", "interface_a_map_hotel_deep_content.html#ad68fd2accba5c86d75aba7369599f115", null ],
    [ "star", "interface_a_map_hotel_deep_content.html#a92c14c3d8218527df192d8a8444fd6a2", null ],
    [ "traffic", "interface_a_map_hotel_deep_content.html#a670b28e184c3ed8d517f762a3f571533", null ]
];