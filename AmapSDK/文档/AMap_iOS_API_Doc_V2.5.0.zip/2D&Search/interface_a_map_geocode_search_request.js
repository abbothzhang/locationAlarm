var interface_a_map_geocode_search_request =
[
    [ "address", "interface_a_map_geocode_search_request.html#a71b9e065768b490828bccb95eb57eade", null ],
    [ "city", "interface_a_map_geocode_search_request.html#aa9de09613cf3fc34300c91b1b4b84fea", null ],
    [ "searchType", "interface_a_map_geocode_search_request.html#a444a1287df93089378ca25d86c9dbbdd", null ]
];