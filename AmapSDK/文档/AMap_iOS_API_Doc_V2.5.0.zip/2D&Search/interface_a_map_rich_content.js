var interface_a_map_rich_content =
[
    [ "discounts", "interface_a_map_rich_content.html#a97eed421ad2adb88e4fc5b5e552b6b82", null ],
    [ "groupbuys", "interface_a_map_rich_content.html#a09fae9bd703968f3675e2627b80f5b10", null ]
];