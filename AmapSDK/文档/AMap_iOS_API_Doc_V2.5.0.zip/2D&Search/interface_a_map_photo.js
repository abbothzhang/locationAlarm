var interface_a_map_photo =
[
    [ "provider", "interface_a_map_photo.html#a6f8749239c9f11e5dd4a95f6134ec59b", null ],
    [ "title", "interface_a_map_photo.html#aadac407b2a8026b5bc5058454a27869b", null ],
    [ "url", "interface_a_map_photo.html#a595d11339d15652426f5446a87985b14", null ]
];