var interface_m_a_circle_view =
[
    [ "initWithCircle:", "interface_m_a_circle_view.html#a83c064987249ca31af4c565e8fd7272a", null ],
    [ "circle", "interface_m_a_circle_view.html#a238df5b0e68f1d2f3811692cdf20b925", null ]
];