var interface_m_a_circle =
[
    [ "boundingMapRect", "interface_m_a_circle.html#a472ef3ad80d86415b79c210d88e0816b", null ],
    [ "coordinate", "interface_m_a_circle.html#a24c9b0c0f3c27f43d82309a05878819c", null ],
    [ "radius", "interface_m_a_circle.html#a818875c0f6ad6fd83d1a805dba15c3d3", null ]
];